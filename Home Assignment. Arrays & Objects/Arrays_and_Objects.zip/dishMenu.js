const dishes = {
    shrimpObj : {
        "dishID" : "001",
        "dishName" : "Garlic Buttered Shrimp 🦐",
        "dishPrice" : 320,
        "ingredients" : ["unsalted butter","peeled and deveined shrimp", "minced garlic","salt","black pepper"],
        },
    porkObj :  {
        "dishID" : "002",
        "dishName" : "Crispy Pata 🐷",
        "dishPrice" : 520,
        "ingredients" : ["pig leg","peppercorn", "garlic powder","salt","black pepper","dried bay leaves"],
        },
    fishObj :  {
        "dishID" : "003",
        "dishName" : "Grilled Tuna Belly 🐟",
        "dishPrice" : 220,
        "ingredients" : ["tuna belly","soy sauce", "sugar","calamansi","ground black pepper"],
        },
};

console.log(dishes);

