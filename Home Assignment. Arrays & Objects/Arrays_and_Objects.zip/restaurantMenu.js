menuObject = {
    "restaurantName" : "Rice Please 🍙",
    "dishes" :  [
                {
                "dishID" : "001",
                "dishName" : "Garlic Buttered Shrimp 🦐",
                "dishPrice" : 320,
                "ingredients" : ["unsalted butter","peeled and deveined shrimp", "minced garlic","salt","black pepper"],
                },
                {
                "dishID" : "002",
                "dishName" : "Crispy Pata 🐷",
                "dishPrice" : 520,
                "ingredients" : ["pig leg","peppercorn", "garlic powder","salt","black pepper","dried bay leaves"],
                },
                {
                "dishID" : "003",
                "dishName" : "Grilled Tuna Belly 🐟",
                "dishPrice" : 220,
                "ingredients" : ["tuna belly","soy sauce", "sugar","calamansi","ground black pepper"],
                }
                ],
        "displayRestaurantName" : function(){
            console.log(this.restaurantName + "\n");
        },
        "displayMenu" : function(){
            for(menu of this.dishes){
                console.log(menu.dishName + ", ₱" + menu.dishPrice + "\n" + "Contains: " + menu.ingredients + "\n");
            }
        }
};
menuObject.displayRestaurantName();
menuObject.displayMenu();