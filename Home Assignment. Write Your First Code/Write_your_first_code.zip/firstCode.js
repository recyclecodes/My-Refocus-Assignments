//Task 1. Hellow World
console.log("Hello World\n");

//Task 2. Capture your goal
console.log("I am gonna be an awesome web developer.\n");

//Tasks 3. Write anything you like
console.log("Have the confidence to face all the challenges as a Full Stack Developer.");