function findUpperCase(str) {
    for (var i = 0; i < str.length; i++)
        if (str[i].toUpperCase() === str[i] && str[i].toLowerCase() !== str[i])
            return console.log(str[i]);
    return console.log("There are noo upper-case letters");
}

findUpperCase("there is a storm coming to the East of the Philippines");
findUpperCase("no more rainy days here, sun is about to show up");