// Create a feature for bank app using callback that allows users to do 3 things:
// Check their balance
// Desposit money
// Withdraw money
// *** It is forbidden to manually modify the balance.

let balance = 0;

function createBankAccount(name, amount, callback) {
    console.log(`Hello ${name}`);
    callback(amount);
}

function depositAmount(amount) {
    balance = amount;
    console.log(`You have deposited ₱${amount} in your bank account, your current balance is ₱` + balance);
}

function withdrawAmount(amount) {
    balance = balance - amount;
    console.log(`You have withdrawn ₱${amount} in your bank account, your current balance is ₱` + balance);
}
createBankAccount("Anthony", 1000, depositAmount);
createBankAccount("Anthony", 100, withdrawAmount);
