// Create a feature for bank app using closure that allows users to do 3 things:
// Check their balance
// Desposit money
// Withdraw money
// *** It is forbidden to manually modify the balance.

function createBankAccount(name) {
    let balance = 0;
    console.log(`Hi ${name}`);

    function depositAmount(amount) {
        balance = balance + amount;
        console.log(`You have deposited ₱${amount} in your bank account, your current balance is ₱` + balance);
    }

    function withdrawAmount(amount) {
        console.log(`Withdraw ₱${amount}`);
        if (balance < amount) {
            console.log("Insufficient balance you only have ₱" + balance + " in your bank account.");
        } else {
            balance = balance - amount;
            console.log(`You have withdrawn ₱${amount} in your bank account, your current balance is ₱` + balance);
        }

    }

    function checkBalance() {
        console.log("Your current balance is ₱" + balance);
    }

    return {
        depositAmount,
        withdrawAmount,
        checkBalance
    };
}

let checkAccount = createBankAccount("Anthony");
checkAccount.depositAmount(10000);
checkAccount.withdrawAmount(20000);
checkAccount.withdrawAmount(2000);
checkAccount.checkBalance();