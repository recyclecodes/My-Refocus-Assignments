// Use the var keyword to declare a variable BPM.
var BPM = 15;
// Add an if statement to check if the pulse rate is ≥40 & ≤100 . Inside the if block, console.log the sentence: "Normal Reading".
// Add an else if to check the pulse rate is ≥101 & ≤109. Inside the else if block, console.log the sentence "Acceptable to continue home monitoring".
// Add another else if block if the pulse rate is ≥110 & ≤130. Inside the else if block, console.log the sentence "Seek advice from health professionals."
// Add one last else if block if the pulse rate is ≥131. Inside the else of block, console.log the sentence "Seek urgent medical advice".
// Add an else statement to capture any other value. Inside the block, type console.log the sentence "The value of the pulse rate is not numerical".

function isPulseRateNormal(BPM) {
    if ( (BPM >= 40) && (BPM <= 100)) {
        console.log("Normal reading.");
    } else if ( (BPM >= 101) && (BPM <= 109)) {
        console.log("Acceptable to continue home monitoring.");
    } else if ( (BPM >= 110) && (BPM <= 130)) {
        console.log("Seek advice from health professionals.");
    } else if (BPM >=131) {
        console.log("Seek urgent medical advice.");
    } else {
        console.log("The value of the pulse rate is not numerical or out of range.");
    } 
}
isPulseRateNormal(BPM);