// Use the var keyword to declare a variable SpO2.
var SpO2 = 96;
// Add an if statement to check if the oxygen saturation is ≥96% . Inside the if block, console.log the sentence: "Normal Reading".
// Add an else if to check the oxygen saturation is =95%. Inside the else if block, console.log the sentence "Acceptable to continue home monitoring".
// Add another else if block if the oxygen saturation is ≥93% & ≤94%. Inside the else if block, console.log the sentence "Seek advice from health professionals."
// Add one last else if block if the oxygen saturation is ≤92%. Inside the else of block, console.log the sentence "Seek urgent medical advice".
// Add an else statement to capture any other value. Inside the block, type console.log the sentence "The value of the oxygen saturation is not numerical".

function isOxygenSaturationNormal(SpO2) {
    if (SpO2 >= 96) {
        console.log("Normal reading.");
    } else if (SpO2 == 95) {
        console.log("Acceptable to continue home monitoring.");
    } else if ( (SpO2 >= 93) && (SpO2 <= 94)) {
        console.log("Seek advice from health professionals.");
    } else if (SpO2 <=92) {
        console.log("Seek urgent medical advice.");
    } else {
        console.log("The value of the oxygen saturation is not numerical or out of range.");
    } 
}
isOxygenSaturationNormal(SpO2);