// Task 3. Add functionality to the system
// Outside the objects, create functions that enable interaction with a user's bank account:
//    getBankAccountDetials <-check username and password are correct and shows the bank account details
//    withdrawMoney <-check username and password are correct and enables getting money from the bank account using the account number
//    depositMoney <-allows putting money to bank account using the account number.


let id = Math.abs(Math.floor(Math.random() * 10000)) + Math.random().toString(36).substring(2, 8);
bankAccount = {
    "bankAccountID": id,
    "accountNumber": "159789123",
    "credentials": [
        ["username", "Anthony"],
        ["password", "thisisapassword"],
        ["pin", "12345"]
    ],
    "balance": 10000,
    "createdAt": new Date().toLocaleDateString('en-us', {
        year: "numeric",
        month: "numeric",
        day: "numeric"
    }),

    "displayBankAccount": function () {
        return {
            bankAccountID: this.bankAccountID,
            accountNumber: this.accountNumber,
            credentials: this.credentials,
            balance: this.balance,
            createdAt: this.createdAt
        }

    },

};
userAccount = {
    "bankAccount": bankAccount.displayBankAccount(),
    "debitCard": "123456789",
    "firtName": "Anthony",
    "lastName": "Serojales",
    "birthDate": "07/28/1991",
    "validID": [
        ["idType", "Driver's License"],
        ["idNumber", "K02192019"]
    ],
    "address": "Block 1 Lot 1 That Street, This City",

    "displayUserAccount": function () {
        return {
            bankAccount: this.bankAccount,
            firtName: this.firtName,
            lastName: this.lastName,
            birthDate: this.birthDate,
            validID: this.validID,
            address: this.address,
        }
    }
};


function getBankAccountDetials(user, pass) {

    let username = bankAccount.credentials[0][1];
    let password = bankAccount.credentials[1][1];
    let account = bankAccount.accountNumber;
    let balance = bankAccount.balance;

    if (username !== user || password !== pass) {
        console.log("Incorrect username or password");
    } else {
        console.log(userAccount.firtName + " " + userAccount.lastName + "\nAccount Number: " + bankAccount.accountNumber + "\nBalance: ₱" + bankAccount.balance);
    };

    function withdrawMoney(user, pass, amount) {
        if (username !== user || password !== pass) {
            console.log("Incorrect username or password")
        } else {
            if (balance < amount) {
                console.log("Insufficient balance you only have ₱" + balance + " in your bank account.");
            } else {
                balance = balance - amount;
                console.log("Account Number: " + bankAccount.accountNumber + `\nYou have withdrawn ₱${amount} in your bank account.`);
            }
        }
    }

    function checkBalance() {
        console.log("Your current balance is ₱" + balance);
    }

    function depositAmount(amount) {
        balance = balance + amount;
        console.log(`A deposit of ₱${amount} will be credited to Account Number: ` + bankAccount.accountNumber);
    }

    return {
        withdrawMoney,
        checkBalance,
        depositAmount
    };
};


let makeTransaction = getBankAccountDetials("Anthony", "thisisapassword");
makeTransaction.withdrawMoney("Anthony", "thisisapassword", 100);
makeTransaction.checkBalance();
makeTransaction.depositAmount(1000);
makeTransaction.checkBalance();