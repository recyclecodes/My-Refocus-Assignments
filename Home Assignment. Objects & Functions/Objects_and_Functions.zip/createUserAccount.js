// Task 2. Create a user account
// Create an object which represents a user account and has the following fields:
// with the following fields:
// bankAccount <- Object from task 1
// debitCard
// firstName
// lastName
// birthDate
// validID <- array type ["idType" , "driver's license"],["idNumber" , "201345421"]
// address

let id = Math.abs(Math.floor(Math.random() * 10000)) + Math.random().toString(36).substring(2, 8);
bankAccount = {
    "bankAccountID": id,
    "accountNumber": "159789123",
    "credentials": [
        ["username", "Anthony"],
        ["password", "thisisapassword"],
        ["pin", "12345"]
    ],
    "balance": 10000,
    "createdAt": new Date().toLocaleDateString('en-us', {
        year: "numeric",
        month: "numeric",
        day: "numeric"
    }),

    "displayBankAccount": function () {
        return {
            bankAccountID: this.bankAccountID,
            accountNumber: this.accountNumber,
            credentials: this.credentials,
            balance: this.balance,
            createdAt: this.createdAt
        }

    },

};
userAccount = {
    "bankAccount": bankAccount.displayBankAccount(),
    "debitCard": "123456789",
    "firtName": "Anthony",
    "lastName": "Serojales",
    "birthDate": "07/28/1991",
    "validID": [
        ["idType", "Driver's License"],
        ["idNumber", "K02192019"]
    ],
    "address": "Block 1 Lot 1 That Street, This City",
    "displayUserAccount": function () {
        console.log(this.bankAccount.bankAccountID);
        console.log(this.bankAccount.accountNumber);
        console.log(this.bankAccount.credentials);
        console.log(this.bankAccount.balance);
        console.log(this.bankAccount.createdAt);
        console.log(this.firtName);
        console.log(this.lastName);
        console.log(this.birthDate);
        console.log(this.validID);
        console.log(this.address);
    }

};

userAccount.displayUserAccount();