// Cycling for 30 minutes burns 225 calories
// Sam did cycling for 15 days

// Store in a variable name caloriesPerHour the number of calories burned per hour.
let caloriesPerHour = 450;

// Count number of times Sam did cycling and store in a variable name numTimesCycling.
let numTimesCycling = 15;

// Store in a variable named cyclingHoursPerDay the number of hours Sam did cycling.
let cyclingHoursPerDay = 0.5;

// Compute total calories burned using caloriesPerHour times numTimesCycling.
// Store result in a variable called totalCaloriesBurned.
let totalCaloriesBurned = caloriesPerHour * numTimesCycling;

// Compute actual calories burned using totalCaloriesBurned times cyclingHoursPerDay.
// Store result in a variable called actualCaloriesBurned.
let actualCaloriesBurned = totalCaloriesBurned * cyclingHoursPerDay;

// Display the message using console.log.
console.log(`"Great work, Sam! After ${cyclingHoursPerDay} hours of cycling everyday for ${numTimesCycling} days, you may lose a total of ${actualCaloriesBurned} calories."`);