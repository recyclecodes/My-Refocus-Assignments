// Sam wants to save 10,000 and has already saved 7,500.

// Store in a variable name targetDeposit the desired deposit sam wants.
let targetDeposit = 10000;

// Store in a variable name actualDeposit the money saved by Sam.
let actualDeposit = 7500;

// Store in a variable name lackingDeposit the money needed to achieve the target.
// Compute lackingDeposit using targetDeposit minus actualDeposit.
let lackingDeposit = targetDeposit - actualDeposit;

// Store in a variable name lackingDepositInPercent.
// Compute lackingDepositInPercent using lackingDeposit divided by targetDeposit then multiply by 100.
let lackingDepositInPercent = (lackingDeposit / targetDeposit)*100;

// Display message using console.log
console.log(`"Thank you for your discipline and hardwork, Sam! You are now ${lackingDepositInPercent}% away from your goal of saving ₱${targetDeposit.toLocaleString()}."`)