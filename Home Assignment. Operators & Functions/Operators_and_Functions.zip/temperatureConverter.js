// Declare functions
// Use Formula
    // Celcius to Kelvin 0°C + 273.15 = 273.15K
    // Fahrenheit to Kelvin (32°F-32) x 5/9 + 273.15 = 273.15K
// Use return keyword to return calculated value.

function convertToKelvin(tempCelcius){
    let tempKelvin = tempCelcius + 273.15;
    return tempKelvin;
    
}



function convertToKelvin1(tempFahrenheit){
    let tempKelvin = (tempFahrenheit - 32) * 5/9 + 273.15;
    return tempKelvin;
}

console.log(convertToKelvin(45)+'K');
console.log(convertToKelvin1(45)+'K');