// Show the total tip based on the meal cost (tip is 10% of the meal cost)
// Declare functions
// Use Formula
    // Total Tip =  total bill * 0.1
// Use return keyword to return calculated value.

function computeTip(totalBill){
    let totalTip = totalBill * 0.1;
    return totalTip;
}

console.log(computeTip(1000));