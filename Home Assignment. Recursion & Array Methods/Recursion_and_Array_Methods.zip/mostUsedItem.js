// Create an algorithm that counts the number of times each element is repeated and shows the result using the consonle.

const arr = ["Web Developer", "Refocus", "Web Developer", "Web Developer", "Refocus", "Awesome"];

let countArr = arr.reduce((count,currentValue) => 
    (count[currentValue] ? ++count[currentValue]:(count[currentValue]=1), count),{});

console.log(countArr); 



