// Use array methods to create two recursive functions:
//  insertToBottom, which adds invoices at the bottom of the list
//  reverseStack, which reverses the order of the invoices

let invoiceList = [
    "Invoice 008",
    "Invoice 007",
    "Invoice 006",
    "Invoice 005",
];


function insertToBottom() {
    for(i = 0; i < arguments.length; i++) {
        if(arguments[i] instanceof Array) {
            invoiceList.push.apply(invoiceList, insertToBottom.apply(this, arguments[i]));
        } else {
            invoiceList.push(arguments[i]);
        }
    }
    return invoiceList;
    
};
function reverseList(arr) {
   const reversed = [];
   for (let i = arr.length-1; i >= 0; i-- ) {
    if (Array.isArray(arr[i])) {
      reversed.push(reverseList(arr[i]))
    } else {
      reversed.push(arr[i])
    }
  }
  return console.log(reversed.join(" "));
}
        

insertToBottom("Invoice 004","Invoice 003","Invoice 002","Invoice 001");
console.log(invoiceList.join(" "));
reverseList(invoiceList);




